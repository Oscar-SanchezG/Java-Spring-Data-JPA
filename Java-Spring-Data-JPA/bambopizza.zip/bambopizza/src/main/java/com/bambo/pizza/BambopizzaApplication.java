package com.bambo.pizza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BambopizzaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BambopizzaApplication.class, args);
	}

}
