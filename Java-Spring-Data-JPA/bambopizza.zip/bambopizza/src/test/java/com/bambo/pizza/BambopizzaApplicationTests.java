package com.bambo.pizza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BambopizzaApplicationTests {

	@Test
	void contextLoads() {
	}

}
